import React, { use, useContext } from "react";
import { useState,createContext } from "react";
import {jwtDecode} from "jwt-decode"
const AuthContext = createContext()

export  function AuthProvider({children}){
    const [user,setUser] = useState(null)

const login = (newToken)=>{
    localStorage.setItem(newToken)
    const payload = jwtDecode(newToken)
    setUser(payload)

}
    return (
        <>
            <AuthContext.Provider value ={{login,user}}>
                {children}
            </AuthContext.Provider>
        </>
    )
}

const useAuth =() => {
    const aa = useContext(AuthContext) 
    return aa
 }
 //context ki values ko use karne ke liye

export default useAuth