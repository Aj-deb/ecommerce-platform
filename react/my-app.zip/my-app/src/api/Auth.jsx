import api from "./axios"

export const loginUser = async(data) =>{
    try{
        const response = await api.post("/users/login/",data)
        return response
    }
    catch(err){
        console.log(err);
        throw err;
    }
}

// axios return promise (resolve,reject)
// then catch
// async await 
// 3 states -> pending fulfieed and rejected
//