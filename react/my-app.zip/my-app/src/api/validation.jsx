function encode(teokn){
    token 
}