import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { StrictMode } from "react";
import { AuthProvider } from "./Context/AuthContext";
const root = ReactDOM.createRoot(
  document.getElementById("root")
);
// const queryClient = QueryClient();
root.render(
    <StrictMode>
        <AuthProvider>
            <App />
            
        </AuthProvider>
    </StrictMode>
    
);
