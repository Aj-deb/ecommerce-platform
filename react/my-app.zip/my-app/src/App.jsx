import React, { useState } from "react";
import ReactDom from "react-dom/client"
import asdsada from "./pages/sowuser"
// import {Route,Routes,Link} from "react-router-dom"
import Login from "./pages/login"
import { AuthProvider } from "./Context/AuthContext";
const App =()=>{
  return (
    <AuthProvider>
       <Login/>
    </AuthProvider>
  )
}

export default App

