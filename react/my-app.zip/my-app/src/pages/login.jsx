import React, { useEffect, useState } from "react";
import App from "../App";
import {loginUser} from "../api/Auth"
import useAuth from "../Context/AuthContext";

const Login =()=>{
    const {login} = useAuth()
    const [email,setEmail] = useState("")//aarnj@gmail
    const [password,setPassword] =useState("")
    const [error,setErrors] = useState("")
    const [loading,setLoading] = useState(false)

    useEffect(()=>{
        setTimeout(()=>{
            setLoading(false)
        },2000)
    },[loading])
    
    const handleSubmit = (e) =>{
        e.preventDefault()
        if(!email || !password  ){
            setErrors("invalid credentials")
        }  
        if(!email.includes("@")){
            setErrors("invalid email")

        try{
            const token = loginUser(email,password)
            console.log("aayush gandamara");
            login(token)
        } //  const response = await api.post("/users/login/",data)
        catch(err){
            console.log("aayush chaaka");
        }


    }
        console.log(e);
        setLoading(true)
    }
    return (
           <div>
                <form onSubmit = {handleSubmit}>
                <p>Email</p>
                <input onChange = {(e)=>setEmail(e.target.value)} name = "email" placeholder="Enter the email"  />
                <p>{error}</p>

                <p>Password</p>
                <input onChange = {(e)=>setPassword(e.target.value)} name = "password" placeholder="Enter the password"/>
                <p>{error}</p>

                <button disabled = {loading} type ="submit">
                    {loading ? "loading...": "login"}
                </button> 
                </form>
           </div>
    )
}

export default Login

