from pydantic import BaseModel

class ProductDetailCreate(BaseModel):
    id :int
    name : str
    description :str
    rating : float
    quantity : int

class ProductDetailReturn(BaseModel):
    name : str
    description :str
    rating : float
    quantity : int
    final_price :float
    image : str
    
    
    