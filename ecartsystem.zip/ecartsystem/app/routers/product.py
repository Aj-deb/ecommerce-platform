from typing import List

from fastapi import APIRouter,Depends,HTTPException,status
from app.schema.product_schema import ProductCreate,ProductReturn
from app.models.user_model import User
from app.models.user_model import Products,ProductDetail
from app.core.db import get_db
from app.schema.productDetail import  ProductDetailCreate, ProductDetailReturn
from app.models.inventory_model import Inventory

router = APIRouter(prefix="/products")

@router.get("/items",response_model=List[ProductReturn])
def get_products(limit:int,page:int,db  = Depends(get_db)):
    products = db.query(Products).offset((page-1)*limit).limit(limit).all()
    return products

@router.post('/create',response_model=ProductReturn)
async def create_product(product: ProductCreate, db  = Depends(get_db)):
    product = Products(name=product.name,price=product.price)
    db.add(product)
    db.commit()
    db.refresh(product)
    return product

@router.get("/{product_id}/detail",response_model=ProductDetailReturn)
def get_Detail(product_id:int ,db  = Depends(get_db)):   
    product = db.query(ProductDetail).join(Products).join(Inventory,isouter = True).filter(ProductDetail.product_id == product_id).first()
    if not product:
        raise HTTPException(status_code=404,detail="Product detail not found")
    return {
        "name" : product.name,
        "description" :product.description,
        "rating" : product.rating,
        "quantity" : product.inventory.quantity,
        "final_price":product.product.price,
        "image" : product.product.url
    }
    
# this route for admin for registering products
@router.post("/detail")
def get_products(data:ProductDetailCreate  ,db  = Depends(get_db)):  
    # product = db.query(ProductDetail).filter(ProductDetail.product_id == data.id).first()
    data = ProductDetail(name=data.name,description=data.description,rating=data.rating,stock=data.stock,product_id = data.id)
    db.add(data)
    db.commit()
    db.refresh(data)
    return data
    
   
