from fastapi import APIRouter,Depends
from app.core.redis_client import redis_client
from app.schema.otp_schema import EmailOtp, Otp, OtpReturn
import random
from app.core.db import get_db
from app.dependencies.secure_login import get_current_user
from app.core.otp import otp_generate
app = APIRouter(prefix="/otp")

@app.post("/")
def otp(email:EmailOtp):
    code = otp_generate()
    redis_client.set(f"otp:{email.email}",str(code),ex=300)
    
@app.post("/verify",response_model=OtpReturn)
def verify_otp(otp:Otp):
    saved_otp = redis_client.get(f"otp:{otp.email}")
    print(type(saved_otp))
    print(type(otp.otp))
    if saved_otp == otp.otp:
        return {
            "success":True,
            "message":"otp verified"
        }
    return {
        "success":False,
        "message":"Not valid"
    }
    